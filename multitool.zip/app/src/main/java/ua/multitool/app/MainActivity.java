package ua.multitool.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayDeque;
import java.util.Locale;

/**
 * Старт: завантажує APK з Dropbox і запускає встановлення.
 *
 * Щоб додати або змінити додаток, відредагуй масив APPS нижче.
 * Посилання береться з Dropbox (кнопка «Копировать ссылку» біля файлу)
 * і в кінці замінюється dl=0 на dl=1, щоб файл качався напряму.
 */
public class MainActivity extends Activity {

    // ---------- СПИСОК ДОДАТКІВ ----------
    private static final AppItem[] APPS = {
            new AppItem(
                    "Awax",
                    "Версія 1.0.100 · 24,5 МБ",
                    "awax-1.0.100.apk",
                    "https://www.dropbox.com/scl/fo/wy50ffu73tv90guagzb1r/AKxK6hT-sjo62mYcNeK7iTE/awax-1.0.100-ORWy.apk?rlkey=s6syjpujodafqwx2pkc7yetwh&dl=1"),
            new AppItem(
                    "ESET",
                    "Антивірус · 51,2 МБ",
                    "eset.apk",
                    "https://www.dropbox.com/scl/fo/wy50ffu73tv90guagzb1r/AK-QDBbhDFnjxyk8FVCMUnc/Eset%2064x.apk?rlkey=s6syjpujodafqwx2pkc7yetwh&dl=1"),
            new AppItem(
                    "Zillya! Антивірус",
                    "Версія 3.8.1 · 22 МБ",
                    "zillya-3.8.1.apk",
                    "https://www.dropbox.com/scl/fo/wy50ffu73tv90guagzb1r/ABJP_uZ1LWjRfJDFanLfAAA/Zillya%20Antivirus%203.8.1.apk?rlkey=s6syjpujodafqwx2pkc7yetwh&dl=1"),
    };
    // -------------------------------------

    private static final String APK_MIME = "application/vnd.android.package-archive";
    private static final int ACCENT = Color.parseColor("#3B5BFF");
    private static final int ACCENT2 = Color.parseColor("#6E8BFF");
    private static final int TEXT_DARK = Color.parseColor("#141A2B");
    private static final int TEXT_MUTED = Color.parseColor("#6B7486");
    private static final int BG = Color.parseColor("#F4F6FB");
    private static final int SURFACE = Color.WHITE;
    private static final int[] BADGE_COLORS = {
            Color.parseColor("#3B5BFF"), // індиго
            Color.parseColor("#17B890"), // зелений
            Color.parseColor("#F3722C"), // помаранчевий
            Color.parseColor("#9B5DE5"), // фіолетовий
            Color.parseColor("#E63946"), // червоний
    };

    private DownloadManager dm;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<AppItem> installQueue = new ArrayDeque<>();
    private boolean installerOpen = false;
    private boolean waitingForPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        prefs = getSharedPreferences("downloads", MODE_PRIVATE);
        getWindow().setStatusBarColor(ACCENT);
        setContentView(buildUi());
        for (AppItem app : APPS) {
            app.downloadId = prefs.getLong(app.fileName, -1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        installerOpen = false;
        if (waitingForPermission) {
            waitingForPermission = false;
            if (!canInstall()) {
                installQueue.clear();
                Toast.makeText(this,
                        "Без дозволу встановлення неможливе. Натисни «Встановити», щоб спробувати ще раз.",
                        Toast.LENGTH_LONG).show();
            }
        }
        handler.removeCallbacks(poller);
        handler.post(poller);
        processInstallQueue();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poller);
    }

    // ---------- Інтерфейс ----------

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);

        root.addView(buildHeader());

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setClipToPadding(false);
        body.setClipChildren(false);
        body.setPadding(dp(16), dp(18), dp(16), dp(28));
        root.addView(body);

        Button all = makeButton("Завантажити все", true);
        all.setOnClickListener(v -> {
            for (AppItem app : APPS) {
                if (!isRunning(app)) startDownload(app);
            }
        });
        LinearLayout.LayoutParams allLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        allLp.bottomMargin = dp(2);
        body.addView(all, allLp);

        for (int i = 0; i < APPS.length; i++) {
            body.addView(buildCard(APPS[i], i));
        }

        TextView note = new TextView(this);
        note.setText("Якщо Android попросить дозвіл «Встановлювати невідомі додатки», увімкни його для «Старту» і повернися назад.");
        note.setTextSize(13);
        note.setLineSpacing(dp(2), 1f);
        note.setTextColor(TEXT_MUTED);
        note.setPadding(dp(4), dp(22), dp(4), 0);
        body.addView(note);

        return scroll;
    }

    /** Градієнтна шапка з назвою додатка. */
    private View buildHeader() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(44), dp(22), dp(30));
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[]{ACCENT, ACCENT2});
        bg.setCornerRadii(new float[]{0, 0, 0, 0, dp(30), dp(30), dp(30), dp(30)});
        hero.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Старт");
        title.setTextSize(33);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(-0.01f);
        title.setTextColor(Color.WHITE);
        hero.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Завантаж потрібні додатки в один дотик");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.parseColor("#DCE4FF"));
        subtitle.setPadding(0, dp(6), 0, dp(18));
        hero.addView(subtitle);

        TextView pill = new TextView(this);
        pill.setText(APPS.length + " додатки");
        pill.setTextSize(13);
        pill.setTypeface(Typeface.DEFAULT_BOLD);
        pill.setTextColor(Color.WHITE);
        pill.setPadding(dp(14), dp(7), dp(14), dp(7));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setColor(Color.parseColor("#33FFFFFF"));
        pillBg.setCornerRadius(dp(100));
        pill.setBackground(pillBg);
        hero.addView(pill, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        return hero;
    }

    private View buildCard(AppItem app, int index) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(SURFACE);
        bg.setCornerRadius(dp(20));
        card.setBackground(bg);
        card.setElevation(dp(5));
        card.setClipToOutline(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        card.setLayoutParams(lp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row);

        int badgeColor = BADGE_COLORS[index % BADGE_COLORS.length];
        TextView badge = new TextView(this);
        badge.setText(app.name.substring(0, 1).toUpperCase(Locale.getDefault()));
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(22);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        GradientDrawable squircle = new GradientDrawable();
        squircle.setShape(GradientDrawable.RECTANGLE);
        squircle.setCornerRadius(dp(16));
        squircle.setColor(badgeColor);
        badge.setBackground(squircle);
        row.addView(badge, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(14), 0, dp(8), 0);
        row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(this);
        name.setText(app.name);
        name.setTextSize(17);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setTextColor(TEXT_DARK);
        texts.addView(name);

        app.statusView = new TextView(this);
        app.statusView.setText(app.description);
        app.statusView.setTextSize(13);
        app.statusView.setTextColor(TEXT_MUTED);
        app.statusView.setPadding(0, dp(2), 0, 0);
        texts.addView(app.statusView);

        app.button = makeButton("Завантажити", false);
        app.button.setOnClickListener(v -> onAppButton(app));
        row.addView(app.button, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)));

        app.progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        app.progress.setMax(100);
        app.progress.setVisibility(View.GONE);
        app.progress.setProgressTintList(ColorStateList.valueOf(badgeColor));
        app.progress.setIndeterminateTintList(ColorStateList.valueOf(badgeColor));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(8));
        plp.topMargin = dp(14);
        card.addView(app.progress, plp);

        return card;
    }

    private Button makeButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(18), 0, dp(18), 0);
        b.setStateListAnimator(null);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(14));
        if (primary) {
            bg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            bg.setColors(new int[]{ACCENT, ACCENT2});
            b.setTextColor(Color.WHITE);
            b.setElevation(dp(3));
        } else {
            bg.setColor(Color.parseColor("#EAEEFF"));
            b.setTextColor(ACCENT);
        }
        b.setBackground(bg);
        return b;
    }

    // ---------- Логіка ----------

    private void onAppButton(AppItem app) {
        if (isRunning(app)) {
            dm.remove(app.downloadId);
            app.downloadId = -1;
            prefs.edit().remove(app.fileName).apply();
            refresh(app);
            return;
        }
        if (isDownloaded(app)) {
            queueInstall(app);
        } else {
            startDownload(app);
        }
    }

    private void startDownload(AppItem app) {
        File target = targetFile(app);
        if (target.exists()) target.delete();
        if (app.downloadId != -1) dm.remove(app.downloadId);

        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(app.url))
                .setTitle(app.name)
                .setDescription("Старт")
                .setMimeType(APK_MIME)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, app.fileName);
        app.downloadId = dm.enqueue(req);
        app.autoInstall = true;
        prefs.edit().putLong(app.fileName, app.downloadId).apply();
        refresh(app);
        handler.removeCallbacks(poller);
        handler.post(poller);
    }

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            boolean anyRunning = false;
            for (AppItem app : APPS) {
                refresh(app);
                if (isRunning(app)) anyRunning = true;
            }
            if (anyRunning) handler.postDelayed(this, 500);
        }
    };

    /** Оновлює стан картки за даними DownloadManager. */
    private void refresh(AppItem app) {
        if (app.button == null) return;
        int status = -1;
        long done = 0, total = -1;
        if (app.downloadId != -1) {
            try (Cursor c = dm.query(new DownloadManager.Query().setFilterById(app.downloadId))) {
                if (c != null && c.moveToFirst()) {
                    status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                }
            }
        }
        app.lastStatus = status;

        switch (status) {
            case DownloadManager.STATUS_PENDING:
            case DownloadManager.STATUS_RUNNING:
            case DownloadManager.STATUS_PAUSED:
                app.progress.setVisibility(View.VISIBLE);
                if (total > 0) {
                    app.progress.setIndeterminate(false);
                    app.progress.setProgress((int) (done * 100 / total));
                    app.statusView.setText(String.format(Locale.US, "Завантаження… %s з %s",
                            mb(done), mb(total)));
                } else {
                    app.progress.setIndeterminate(true);
                    app.statusView.setText(status == DownloadManager.STATUS_PAUSED
                            ? "Очікування мережі…" : "Підключення…");
                }
                app.button.setText("Скасувати");
                break;
            case DownloadManager.STATUS_SUCCESSFUL:
                app.progress.setVisibility(View.GONE);
                app.statusView.setText("Завантажено · " + mb(total > 0 ? total : done));
                app.button.setText("Встановити");
                if (app.autoInstall) {
                    app.autoInstall = false;
                    queueInstall(app);
                }
                break;
            case DownloadManager.STATUS_FAILED:
                app.progress.setVisibility(View.GONE);
                app.statusView.setText("Помилка завантаження. Перевір інтернет і спробуй ще.");
                app.button.setText("Повторити");
                app.autoInstall = false;
                break;
            default:
                app.progress.setVisibility(View.GONE);
                app.statusView.setText(app.description);
                app.button.setText("Завантажити");
        }
    }

    private void queueInstall(AppItem app) {
        if (!installQueue.contains(app)) installQueue.add(app);
        processInstallQueue();
    }

    /** Встановлення запускаються по черзі: наступне після повернення з вікна встановлення. */
    private void processInstallQueue() {
        if (installerOpen || installQueue.isEmpty() || isFinishing()) return;
        if (!canInstall() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!waitingForPermission) {
                waitingForPermission = true;
                Toast.makeText(this,
                        "Дозволь «Старту» встановлювати додатки і повернися назад",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())));
            }
            return;
        }
        AppItem app = installQueue.poll();
        Uri uri = dm.getUriForDownloadedFile(app.downloadId);
        if (uri == null) {
            Toast.makeText(this, app.name + ": файл не знайдено, завантаж ще раз", Toast.LENGTH_LONG).show();
            app.downloadId = -1;
            prefs.edit().remove(app.fileName).apply();
            refresh(app);
            processInstallQueue();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, APK_MIME)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            installerOpen = true;
            startActivity(intent);
        } catch (Exception e) {
            installerOpen = false;
            Toast.makeText(this, "Не вдалося відкрити встановлення: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private boolean canInstall() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || getPackageManager().canRequestPackageInstalls();
    }

    private boolean isRunning(AppItem app) {
        return app.lastStatus == DownloadManager.STATUS_PENDING
                || app.lastStatus == DownloadManager.STATUS_RUNNING
                || app.lastStatus == DownloadManager.STATUS_PAUSED;
    }

    private boolean isDownloaded(AppItem app) {
        return app.lastStatus == DownloadManager.STATUS_SUCCESSFUL && targetFile(app).exists();
    }

    private File targetFile(AppItem app) {
        return new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), app.fileName);
    }

    private static String mb(long bytes) {
        return String.format(Locale.US, "%.1f МБ", bytes / 1048576.0);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- Модель ----------

    static final class AppItem {
        final String name, description, fileName, url;
        long downloadId = -1;
        int lastStatus = -1;
        boolean autoInstall = false;
        TextView statusView;
        Button button;
        ProgressBar progress;

        AppItem(String name, String description, String fileName, String url) {
            this.name = name;
            this.description = description;
            this.fileName = fileName;
            this.url = url;
        }
    }
}
